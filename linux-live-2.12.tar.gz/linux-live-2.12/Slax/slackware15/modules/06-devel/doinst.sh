#!/bin/bash
# $1 = union
#rm $1/usr/lib*/libncurses{++.a,++w.a,.a,w.a}
