#!/bin/sh
# Set VISUAL variable to mcedit, so mcedit will be used
# instead of `vi' for crontab -e and in many more situations
export VISUAL=mcedit
